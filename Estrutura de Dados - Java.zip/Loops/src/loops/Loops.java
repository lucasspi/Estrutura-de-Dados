
package loops;


public class Loops {

    public static void main(String[] args) {
        
        
       /* while(numero <= 5){ //enquanto numero for menor que cinco]
            numero++;
            System.out.println("Numero é: "+ numero);
            
        }
        System.out.println("Saiu do While");
        */
       
       /* do {// ele executa primeiro e depois faz a verificação da condição
            numero++;
            System.out.println("Numero é: "+ numero);
        } while (numero <= 5);*/
        for (int numero = 0; numero < 5; numero++) {
             System.out.println("Numero é: "+ numero);
             //inicializa com 0, depois tem a condição e depois o incremento
            
        }
        
    }
    
}
