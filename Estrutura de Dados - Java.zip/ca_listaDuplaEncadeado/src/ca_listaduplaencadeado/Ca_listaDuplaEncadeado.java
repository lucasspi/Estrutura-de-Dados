
package ca_listaduplaencadeado;

public class Ca_listaDuplaEncadeado {

    public static void main(String[] args) {
        
        Lista li = new Lista();
        
        li.insereFim(1);
        li.insereFim(2);
        li.insereFim(3);
        li.insereFim(4);
        
        li.imprimeDireita();
        
        li.imprimeEsquerda();
        
        li.getElemento();
        
        
        
    }
    
}
